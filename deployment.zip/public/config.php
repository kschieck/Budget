<?php

// Database connection config
$servername = "localhost";
$username = "u609148805_web";
$password = "9a&/-&GzdN3!6Fu";
$dbname = "u609148805_budget";

$secretkey = "w3oj45h6ip3jn4ti423ntin234tiougn423otn2i4nto24t";

$authusers = [
    "kyle" => '$2y$10$oZgNs1N6ihw51WAPq/.Dz.oh/8a/OiwkVGgPudSUQsGKizretHEA2',
    "lexie" => '$2y$10$zQ5o8Y4eQT9D3IyQrlra/eBKNBLBJKisqB/JZVMM7ISFpeU.csjiK'
];

?>